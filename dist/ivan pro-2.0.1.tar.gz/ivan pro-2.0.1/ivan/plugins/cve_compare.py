from .database import db_query
import click
import csv
import textwrap


@click.command(help="Pull out CVE data into a nice CSV")
@click.argument('ip')
def compare(ip):
    data = db_query("select plugin_id, plugin_name, cvss_base_score, cvss3_base_score,  cves, severity, score, "
                    "first_found, last_found from vulns where asset_ip='{}' and cves !=' ';".format(ip))

    with open('cve_data_{}.csv'.format(ip), mode='w', encoding='utf-8', newline="") as csv_file:
        agent_writer = csv.writer(csv_file, delimiter=',', quotechar='"')

        header_list = ["Plugin ID", "Plugin Name", "CVE", "CVSS", "CVSS3", "VPR Score", "EPSS Score", "Severity",
                       "First Found",
                       "Last_Found", "Instances"]

        agent_writer.writerow(header_list)

        master_list = []
        click.echo("\n{:10} {:75} {:16} {:6} {:6} {:6} {:7} {:10} {}".format("Plugin ID", "Plugin Name", "CVE",
                                                                             "CVSS", "CVSS3", "VPR", "EPSS",
                                                                             "Severity", "instances"))
        click.echo("-" * 150)
        for plugin in data:
            plugin_id = plugin[0]
            plugin_name = str(plugin[1])
            cvss = str(plugin[2])
            cvss3 = str(plugin[3])

            try:
                cve_list = eval(plugin[4])
            except SyntaxError:
                cve_list = ["NO-CVE"]

            severity = plugin[5]
            vpr = str(plugin[6])
            first_found = str(plugin[7])
            last_found = str(plugin[8])

            for cve in cve_list:
                epss_data = 'N/A'
                if cve not in master_list:
                    # Count total instances
                    instances = db_query("select count(*) from vulns where cves LIKE '%" + cve + "%';")

                    master_list.append(cve)
                    try:
                        epss_data_raw = db_query("select epss_value from epss where cve='{}'".format(cve))
                        epss_data = str(epss_data_raw[0][0])
                    except:
                        pass
                    click.echo("{:10} {:75} {:16} {:6} {:6} {:6} {:7} {:10} {}".format(plugin_id,
                                                                                       textwrap.shorten(plugin_name,
                                                                                                        width=65), cve,
                                                                                       cvss, cvss3, vpr, epss_data,
                                                                                       severity, instances[0][0]))

                    csv_update_list = [plugin_id, plugin_name, cve, cvss, cvss3, vpr, epss_data, severity,
                                       first_found, last_found, instances[0][0]]
                    agent_writer.writerow(csv_update_list)

    click.echo("\nYou're export: cve_compare_{}.csv is finished\n".format(ip))
